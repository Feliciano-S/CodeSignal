def solution(s):
    if s == s[::-1]:
        return True
    return False
